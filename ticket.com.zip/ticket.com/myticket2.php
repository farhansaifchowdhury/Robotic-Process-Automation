
<?php
$mysqli = new mysqli("localhost", "root", "root", "test");
if($mysqli->connect_error) {
  exit('Could not connect');
}

$sql = "UPDATE OPENTICKET SET status='Solved' WHERE ticketid = ?";
#mysqli_query($mysqli,$sql);
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $_GET['q']);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($sql,$status);
$stmt->fetch();
$stmt->close();
?>
