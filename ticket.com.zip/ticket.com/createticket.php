<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Create Ticket</title>
   </head>
   <body>
      <center>
         <h1>Create Ticket</h1>
         <form action="insert.php" method="post">
             
<p>
               <label for="employeeid">EmployeeID:</label>
               <input type="text" name="employeeid" id="employeeid">
            </p>
 
             
<p>
               <label for="appname">Application Name</label>
      	    <select name="appname" id="appname">
    		<option value="Domain1.com">Domain 1</option>
    		<option value="Domain2.com">Domain 2</option>
    		<option value="Domain3.com">Domain 3</option>
    		<option value="Domain4.com">Domain 4</option>
  	   </select>
 	   </p>	
 
            <input type="submit" value="Submit">
         </form>
      </center>
   </body>
</html>
