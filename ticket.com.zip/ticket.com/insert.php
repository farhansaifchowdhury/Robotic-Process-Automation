<!DOCTYPE html>
<html>
 
<head>
    <title>Create Ticket</title>
</head>
 
<body>
    <center>
        <?php
 
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        $conn = mysqli_connect("localhost", "root", "root", "test");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $employee_id =  $_REQUEST['employeeid'];
        $app_name = $_REQUEST['appname'];
              
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO OPENTICKET (user_name,app_name,task,status)  VALUES ('$employee_id','$app_name','password_reset','Open')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>Ticket Created Successfully."
                . ""
                . "</h3>";
 
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>
