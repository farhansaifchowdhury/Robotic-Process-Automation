
<!DOCTYPE html>

<html>

<head>

    <title>HOME</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
	<h1>PASSWORD RESET SUCCESSFUL</h1>

 </body>

</html>


