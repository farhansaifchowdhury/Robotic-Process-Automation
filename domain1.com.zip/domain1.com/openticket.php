<?php

session_start(); 

include "db_conn.php";

// Username is root
//$user = 'root';
//$password = ''; 
  
// Database name is gfg
//$database = 'gfg'; 
  
// Server is localhost with
// port number 3308
//$servername='localhost:3308';
//$mysqli = new mysqli($servername, $user, $password, $database)
                ;
  
// Checking for connections
//if ($mysqli->connect_error) {
    //die('Connect Error (' . 
    //$mysqli->connect_errno . ') '. 
    //$mysqli->connect_error);
//}
  
// SQL query to select data from database
$sql = "SELECT * FROM OPENTICKET ORDER BY ticketid ASC ";
$result = mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <title>Ticket</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
  
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT', 
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
  
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
  
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
  
        td {
            font-weight: lighter;
	}

.wrapper {
    text-align: center;
}

.button {
    position: absolute;
    top: 7%;
	right:30%
	
}
    </style>
</head>
  
<body>
    <section>
	<h1>Open Ticket</h1>
<div class="wrapper">
    <button class="button" onCLick="window.location.reload();">Save</button>
</div>

        <!-- TABLE CONSTRUCTION-->
        <table>
            <tr>
                <th>TICKET ID</th>
                <th>USER NAME</th>
                <th>TASK</th>
                <th>Open/Solved</th>
                <th>Status</th>
              
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php   // LOOP TILL END OF DATA 
                while($rows=$result->fetch_assoc())
                {
             ?>
            <tr>
                <!--FETCHING DATA FROM EACH 
                    ROW OF EVERY COLUMN-->
                <td><?php echo $rows['ticketid'];?></td>
                <td><?php echo $rows['user_name'];?></td>
                <td><?php echo $rows['task'];?></td>
                <td id="status"><?php echo $rows['status'];?></td>
                <td id="demo">
                    <form action=""> 
                    <select name="OPENTICKET" onchange="showCustomer(this.value)">
                    <option value="">Status</option>
                    <option value="<?php echo $rows['ticketid'];?>">Solved</option>
                    <option value="<?php echo $rows['ticketid'];?>">Open</option>
                    </select>
                    </form>
                </td>
            </tr>
            <?php
                }
             ?>
        </table>
    </section>
<script>
function showCustomer(str) {
    var xhttp;    
    if (str == "") {
    document.getElementById("status").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 1 && this.status == 1) {
      document.getElementById("status").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "openticket2.php?q="+str, true);
  xhttp.send();
  //xhttp.open("GET", "inserintosolve.php?q="+str, true);
  //xhttp.send();
  //xhttp.open("GET", "deletefromopen.php?q="+str, true);
  //xhttp.send();
  
  
}
</script>
</body>
  
</html>

