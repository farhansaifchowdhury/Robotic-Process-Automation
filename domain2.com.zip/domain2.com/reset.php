<?php 

session_start(); 

include "db_conn1.php";


    $uname = $_POST['uname'];

    $pass = $_POST['password'];

    if (empty($uname)) {

        header("Location: index.php?error=User Name is required");

        exit();

    }else if(empty($pass)){

        header("Location: index.php?error=Password is required");

        exit();

    }else{

        $sql = "UPDATE user SET password='$pass' WHERE user_name='$uname'";
        mysqli_query($conn,$sql);
		header("Location: resetsuccessful.php");

		   

    }



        

